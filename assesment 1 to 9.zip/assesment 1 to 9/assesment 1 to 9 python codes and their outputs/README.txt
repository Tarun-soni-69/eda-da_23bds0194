EDA THEORY DA - PYTHON PACK
Name: Tarun Soni | Registration No.: 23BDS0194

FILES
assessment1.py ... assessment9.py : Python versions of the nine EDA DAs discussed.
common.py : dataset loader and plotting helper.
run_all_assessments.py : runs all nine in order.
video_scripts/ : short explanation scripts for recording each DA.
outputs/ : plots generated when you run the scripts.

SETUP
1. Extract this ZIP.
2. Open a terminal in the extracted folder.
3. Install dependencies: python -m pip install -r requirements.txt
4. Run all: python run_all_assessments.py
5. Or run one: python assessment4.py

DATASET IMPORTANT
Assessments 2-5, 7 and 8 use supermarket_sales.csv. This ZIP includes the cleaned 1,000-row, 17-column CSV based on the exact source URL supplied by the student. The loader checks for the local file first, normalizes the source column names, and only attempts the public URL if the local CSV is absent. A clearly labelled synthetic fallback remains only for offline use if no CSV is available.
Assessment 6 uses the embedded monthly AirPassengers series. Assessment 9 uses the six mtcars variables required by the PCA task.


Supermarket sales dataset source supplied by student:
https://raw.githubusercontent.com/salemprakash/EDA/main/Data/supermarket_sales.csv
The scripts first use a local CSV, then attempt to download this exact URL. If the runtime has no internet and no local CSV, they fall back to demo data; do not submit demo-data plots as actual findings.
