import pandas as pd
from common import banner
def run():
 banner('ASSESSMENT 1 - DATAFRAME OPERATIONS AND TRANSFORMATIONS')
 d1=pd.DataFrame({'ProductID':range(101,111),'NameofProd':['Laptop','Mouse','Keyboard','Monitor','Printer','Scanner','Tablet','Speaker','Router','Camera'],'Price':[55000,800,1500,12000,9000,6500,22000,3000,2500,18000]})
 d2=pd.DataFrame({'ProductID':range(101,111),'Company_Location':['Delhi','Mumbai','Chennai','Bangalore','Hyderabad','Kolkata','Pune','Noida','Ahmedabad','Guwahati']})
 d3=pd.DataFrame({'ProductID':range(111,121),'NameofProd':['Projector','Pendrive','HardDisk','Smartwatch','Microphone','Headphones','SSD','UPS','GraphicsCard','Webcam'],'Price':[35000,600,4500,8000,2500,4000,7000,5000,28000,2200]})
 print('Q1 DataFrames\n',d1.to_string(index=False),'\n',d2.to_string(index=False),'\n',d3.to_string(index=False))
 print('\nQ2 Append\n',pd.concat([d1,d3],ignore_index=True).to_string(index=False)); print('\nQ3 Horizontal concatenate\n',pd.concat([d1,d2[['Company_Location']]],axis=1).to_string(index=False)); print('\nQ4 Merge\n',d1.merge(d2,on='ProductID').to_string(index=False))
 for q,h in [('Q5 Inner','inner'),('Q6 Left','left'),('Q7 Right','right'),('Q8 Full outer','outer')]: print('\n'+q+'\n',d1.merge(d2,on='ProductID',how=h).to_string(index=False))
 x=pd.Series([1234,45,67,89,23,56,78,91,34,12],dtype=float); span=x.max()-x.min(); print('\nQ9 normalize [-3,3]',(((x-x.min())/span)*6-3).round(4).tolist()); print('normalize [-1,1]',(((x-x.min())/span)*2-1).round(4).tolist()); print('min-max [0,1]',((x-x.min())/span).round(4).tolist()); print('z-score',((x-x.mean())/x.std()).round(4).tolist()); j=len(str(int(x.abs().max()))); print('decimal scaling j=',j,(x/10**j).round(6).tolist()); print('ASSESSMENT 1 COMPLETED')
if __name__=='__main__': run()
