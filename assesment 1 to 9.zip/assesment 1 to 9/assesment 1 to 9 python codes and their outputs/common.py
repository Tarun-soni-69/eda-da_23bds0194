from pathlib import Path
import urllib.request
import pandas as pd
import numpy as np
BASE=Path(__file__).resolve().parent
OUT=BASE/'outputs'; OUT.mkdir(exist_ok=True)
def banner(title): print('\n'+'='*70+'\n'+title+'\nName: Tarun Soni | Registration No.: 23BDS0194\n'+'='*70)
def normalize_supermarket_columns(df):
    # Standardize the source CSV headers to the names used in the assessment scripts.
    rename = {'Invoice ID':'Invoice.ID', 'Customer type':'Customer.type',
              'Product line':'Product.line', 'Unit price':'Unit.price',
              'Tax 5%':'Tax.5.', 'gross income':'gross.income',
              'gross margin percentage':'gross.margin.percentage'}
    return df.rename(columns=rename)

def supermarket_data():
    # Use the exact dataset source supplied by the student.
    source_url = 'https://raw.githubusercontent.com/salemprakash/EDA/main/Data/supermarket_sales.csv'
    for p in [BASE/'supermarket_sales.csv', Path.cwd()/'supermarket_sales.csv']:
        if p.exists() and p.stat().st_size > 1000:
            print('Using local supermarket sales dataset:', p)
            return normalize_supermarket_columns(pd.read_csv(p)), 'local CSV from salemprakash/EDA'
    try:
        print('Downloading supermarket sales dataset from:', source_url)
        df = normalize_supermarket_columns(pd.read_csv(source_url))
        if len(df) < 100 or 'Total' not in df.columns:
            raise ValueError('Downloaded file does not look like the expected supermarket-sales dataset.')
        # Keep a local copy so subsequent assessment scripts can reuse the same data.
        df.to_csv(BASE/'supermarket_sales.csv', index=False)
        print(f'Using downloaded dataset: {len(df)} rows, {len(df.columns)} columns')
        return df, 'downloaded CSV from salemprakash/EDA'
    except Exception as exc:
        print('WARNING: Unable to download the real CSV in this environment:', exc)
        print('A deterministic demo dataset is being used only as a fallback. On a computer with internet, rerun to use the real CSV automatically.')
        rng=np.random.default_rng(331); n=300; q=rng.integers(1,11,n); price=np.round(rng.uniform(10,100,n),2); tax=price*q*.05
        d=pd.DataFrame({'Invoice.ID':[f'INV-{i:04}' for i in range(n)],'Branch':rng.choice(['A','B','C'],n),'City':rng.choice(['Yangon','Naypyitaw','Mandalay'],n),'Customer.type':rng.choice(['Member','Normal'],n),'Gender':rng.choice(['Female','Male'],n),'Product.line':rng.choice(['Health and beauty','Electronic accessories','Home and lifestyle','Sports and travel','Food and beverages','Fashion accessories'],n),'Unit.price':price,'Quantity':q,'Tax.5.':np.round(tax,2),'Total':np.round(price*q+tax,2),'Date':pd.date_range('2019-01-01',periods=n,freq='D').strftime('%m/%d/%Y'),'Payment':rng.choice(['Cash','Credit card','Ewallet'],n),'cogs':np.round(price*q,2),'gross.income':np.round(tax,2),'Rating':np.round(rng.uniform(4,10,n),1)})
        return d,'synthetic demo fallback (network unavailable)'

def savefig(name):
    import matplotlib.pyplot as plt
    p=OUT/name; plt.tight_layout(); plt.savefig(p,dpi=130,bbox_inches='tight'); plt.close(); print('Plot saved:',p)
def mode_value(s):
    m=s.dropna().mode(); return m.iloc[0] if len(m) else 'Unknown'
