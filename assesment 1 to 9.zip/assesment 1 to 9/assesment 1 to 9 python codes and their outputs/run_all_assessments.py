from pathlib import Path
import subprocess,sys
base=Path(__file__).resolve().parent
for i in range(1,10):
 name=f'assessment{i}.py'; print('\n'+'#'*70+'\nRUNNING '+name+'\n'+'#'*70,flush=True)
 r=subprocess.run([sys.executable,str(base/name)],cwd=base)
 if r.returncode: print('FAILED:',name,'exit code',r.returncode); sys.exit(r.returncode)
print('\nALL NINE ASSESSMENTS FINISHED. Check outputs/.')
