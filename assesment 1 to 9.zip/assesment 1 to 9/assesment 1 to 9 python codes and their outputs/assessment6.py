import pandas as pd,numpy as np,matplotlib.pyplot as plt
from common import banner,savefig

def run():
 banner('ASSESSMENT 6 - TIME SERIES ANALYSIS')
 vals=[112,118,132,129,121,135,148,148,136,119,104,118,115,126,141,135,125,149,170,170,158,133,114,140,145,150,178,163,172,178,199,199,184,162,146,166,171,180,193,181,183,218,230,242,209,191,172,194,196,196,236,235,229,243,264,272,237,211,180,201,204,188,235,227,234,264,302,293,259,229,203,229,242,233,267,269,270,315,364,347,312,274,237,278,284,277,317,313,318,374,413,405,355,306,271,306,315,301,356,348,355,422,465,467,404,347,305,336,340,318,362,348,363,435,491,505,404,359,310,337,360,342,406,396,420,472,548,559,463,407,362,405,417,391,419,461,472,535,622,606,508,461,390,432]
 air=pd.Series(vals,index=pd.date_range('1949-01-01',periods=144,freq='MS'),name='Passengers'); print('Q1 Loaded AirPassengers.\nQ2 first five\n',air.head().to_string(),'\nlast five\n',air.tail().to_string()); print('Q3 Start/end:',air.index.min(),air.index.max()); print('Q4 Frequency monthly (12/year); summary\n',air.describe().to_string()); plt.figure(figsize=(10,4)); plt.plot(air); plt.title('Q5 Monthly Air Passengers'); plt.ylabel('Passengers'); savefig('A6_Q5_series.png')
 trend=air.rolling(12,center=True).mean(); seas=(air-trend).groupby(air.index.month).mean(); seasonal=pd.Series([seas.get(m,np.nan) for m in air.index.month],index=air.index); resid=air-trend-seasonal; fig,axs=plt.subplots(4,1,figsize=(10,9),sharex=True); axs[0].plot(air); axs[0].set_title('Observed'); axs[1].plot(trend); axs[1].set_title('Trend'); axs[2].plot(seasonal); axs[2].set_title('Estimated seasonal component'); axs[3].plot(resid); axs[3].set_title('Residual'); fig.suptitle('Q6-Q7 Time Series Decomposition'); savefig('A6_Q6_Q7_decomposition.png')
 try:
  from statsmodels.graphics.tsaplots import plot_acf,plot_pacf
  fig,ax=plt.subplots(); plot_acf(air,lags=36,ax=ax); ax.set_title('Q8 ACF'); savefig('A6_Q8_acf.png'); fig,ax=plt.subplots(); plot_pacf(air,lags=36,method='ywm',ax=ax); ax.set_title('Q8 PACF'); savefig('A6_Q8_pacf.png')
  from statsmodels.tsa.arima.model import ARIMA
  model=ARIMA(air,order=(1,1,1),seasonal_order=(1,1,1,12)).fit(); print('Q9-Q10 ARIMA summary\n',model.summary()); fc=model.get_forecast(12); print('Q11 forecast\n',fc.predicted_mean.to_string()); ci=fc.conf_int(); plt.figure(figsize=(10,4)); plt.plot(air,label='Actual'); plt.plot(fc.predicted_mean,label='Forecast'); plt.fill_between(fc.predicted_mean.index,ci.iloc[:,0],ci.iloc[:,1],alpha=.2); plt.legend(); plt.title('Q12 Actual and Forecast'); savefig('A6_Q12_forecast.png')
 except Exception as e: print('Optional statsmodels step could not run:',e)
 print('ASSESSMENT 6 COMPLETED')
if __name__=='__main__': run()
