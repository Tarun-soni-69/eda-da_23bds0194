import pandas as pd,numpy as np,matplotlib.pyplot as plt
from common import banner,supermarket_data,savefig,mode_value
def run():
 banner('ASSESSMENT 3 - DATA CLEANING AND UNIVARIATE ANALYSIS'); d,src=supermarket_data(); print('Source:',src,'\nQ1 preview\n',d.head().to_string(index=False)); print('Q2 head/tail\n',d.head(6).to_string(index=False),'\n',d.tail(6).to_string(index=False)); print('Q3 missing total',d.isna().sum().sum()); print('Q4 rows with missing\n',d[d.isna().any(axis=1)].to_string(index=False)); mp=d.isna().mean()*100; print('Q5 missing %\n',mp.to_string()); d=d.loc[:,mp<=70].copy(); nums=d.select_dtypes(include=np.number).columns
 dm=d.copy()
 for c in nums: dm[c]=dm[c].fillna(dm[c].mean())
 print('Q6 numeric mean imputation done'); dn=d.copy()
 for c in nums: dn[c]=dn[c].fillna(dn[c].median())
 print('Q7 numeric median imputation done'); dc=d.copy()
 for c in dc.columns:
  if dc[c].dtype=='object' or str(dc[c].dtype)=='category': dc[c]=dc[c].fillna(mode_value(dc[c]))
 print('Q8 categorical mode imputation done'); print('Q9 duplicate rows',d.duplicated().sum()); d=d.drop_duplicates().copy(); print('Q10 rows after deduplication',len(d)); print('Q11 types\n',d.dtypes.to_string())
 for c in d.select_dtypes(include='object').columns: d[c]=d[c].astype('category')
 print('Q12 converted text to category');
 if 'Product.line' in d: d['Product.line_lower']=d['Product.line'].astype(str).str.lower()
 if 'City' in d: d['City_upper']=d['City'].astype(str).str.upper()
 print('Q13 case conversion\n',d.head().to_string(index=False))
 if 'Total' in d:
  x=pd.to_numeric(d['Total'],errors='coerce').dropna(); plt.figure(); plt.boxplot(x); plt.title('Q14 Boxplot of Total'); savefig('A3_Q14_boxplot.png'); q1,q3=x.quantile(.25),x.quantile(.75); i=q3-q1; out=x[(x<q1-1.5*i)|(x>q3+1.5*i)]; print('Q15 IQR outlier count',len(out)); clean=x[(x>=q1-1.5*i)&(x<=q3+1.5*i)]; print('Q16 retained within IQR fences',len(clean)); plt.figure(); plt.hist(x,bins=25,edgecolor='black'); plt.title('Q17 Histogram of Total'); savefig('A3_Q17_histogram.png'); plt.figure(); plt.hist(x,bins=25,density=True,alpha=.5,edgecolor='black')
  try:
   from scipy.stats import gaussian_kde
   xx=np.linspace(x.min(),x.max(),200); plt.plot(xx,gaussian_kde(x)(xx))
  except Exception: pass
  plt.title('Q18 Histogram and density'); savefig('A3_Q18_density.png'); print('Q19 Total summary\n',x.describe().to_string())
 print('ASSESSMENT 3 COMPLETED')
if __name__=='__main__': run()
