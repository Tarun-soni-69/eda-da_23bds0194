import pandas as pd, numpy as np
from common import banner,supermarket_data,mode_value
def run():
 banner('ASSESSMENT 2 - DATA EXPLORATION AND MISSING VALUES'); df,src=supermarket_data(); print('Source:',src); print('Q2 First 10\n',df.head(10).to_string(index=False)); print('Q3 Last 10\n',df.tail(10).to_string(index=False)); print('Q4 shape',df.shape,'\nQ5 columns',df.columns.tolist(),'\nQ6 types\n',df.dtypes.to_string()); print('Q7 summary\n',df.describe(include='all').to_string()); print('Q8 missing\n',df.isna().sum().to_string(),'\nQ9 total missing',df.isna().sum().sum()); print('Q10 missing\n',df.isna().sum().to_string())
 d=df.copy()
 for c,i in [('Quantity',0),('Total',1),('Gender',2),('Payment',3)]:
  if c in d and len(d)>i: d.loc[d.index[i],c]=np.nan
 print('Q11 rows with NA\n',d[d.isna().any(axis=1)].to_string(index=False)); print('Q12 rows after dropna',len(d.dropna()))
 if 'Quantity' in d: d['Quantity']=pd.to_numeric(d['Quantity'],errors='coerce'); d['Quantity']=d['Quantity'].fillna(d['Quantity'].mean())
 if 'Total' in d: d['Total']=pd.to_numeric(d['Total'],errors='coerce'); d['Total']=d['Total'].fillna(d['Total'].median())
 if 'Gender' in d: d['Gender']=d['Gender'].fillna(mode_value(d['Gender']))
 if 'Payment' in d: d['Payment']=d['Payment'].ffill().bfill()
 print('Q13-Q17 mean/median/mode imputation and forward/backward fill complete'); d=d.fillna('Unknown'); print('Q18 remaining NA',d.isna().sum().sum()); print('Q19 unique rows',len(df.drop_duplicates()))
 for c in ['Branch','City','Gender','Customer.type','Payment','Product.line']:
  if c in df: df[c]=df[c].astype('category')
 print('Q20 types\n',df.dtypes.to_string()); df=df.rename(columns={k:v for k,v in {'Invoice.ID':'Invoice_No','Unit.price':'Unit_Price'}.items() if k in df});
 if 'Total' in df and 'gross.income' in df: df['FinalAmount']=pd.to_numeric(df['Total'],errors='coerce')+pd.to_numeric(df['gross.income'],errors='coerce')
 print('Q21-Q22 renamed columns and derived column\n',df.head().to_string(index=False)); print('Q23 summary\n',df.describe(include='all').to_string())
 if 'Total' in df:
  x=pd.to_numeric(df['Total'],errors='coerce').dropna(); print('Q24 min/max',x.min(),x.max(),'Q25 range',(x.min(),x.max()),'Q26 variance',x.var(),'Q27 SD',x.std(),'Q28 IQR',x.quantile(.75)-x.quantile(.25))
 print('ASSESSMENT 2 COMPLETED')
if __name__=='__main__': run()
