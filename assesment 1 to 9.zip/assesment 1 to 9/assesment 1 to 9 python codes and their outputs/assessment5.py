import pandas as pd,numpy as np,matplotlib.pyplot as plt
from pandas.plotting import scatter_matrix,parallel_coordinates
from common import banner,supermarket_data,savefig
def run():
 banner('ASSESSMENT 5 - MULTIVARIATE ANALYSIS'); d,src=supermarket_data(); print('Source:',src); num=d.select_dtypes(include=np.number); print('Q1 Numeric:',list(num.columns),'\nCategorical:',list(d.select_dtypes(exclude=np.number).columns)); colour='Gender'; shape='Customer.type'; x=d['Unit.price']; y=d['Total']
 def group_scatter(title,file,shape_by=False,size_by=False):
  plt.figure(); groups=d[colour].astype(str); shapes=d[shape].astype(str); markers=['o','s','^','D','v','P']
  for i,g in enumerate(groups.unique()):
   for j,h in enumerate(shapes.unique() if shape_by else ['all']):
    m=(groups==g) & ((shapes==h) if shape_by else True); kw={'alpha':.6,'label':f'{g} / {h}' if shape_by else g}
    if shape_by: kw['marker']=markers[j%len(markers)]
    if size_by: kw['s']=pd.to_numeric(d.loc[m,'Quantity'],errors='coerce').fillna(1)*10
    plt.scatter(x[m],y[m],**kw)
  plt.xlabel('Unit Price'); plt.ylabel('Total'); plt.title(title); plt.legend(); savefig(file)
 group_scatter('Q2 Scatter: color = Gender','A5_Q2_color.png'); group_scatter('Q3 Scatter: color + marker','A5_Q3_shape.png',True); group_scatter('Q4 Scatter: point size = Quantity','A5_Q4_size.png',False,True); plt.figure(); plt.scatter(x,y,s=d['Quantity']*10,alpha=.5); plt.xlabel('Unit Price'); plt.ylabel('Total'); plt.title('Q5 Bubble Plot'); savefig('A5_Q5_bubble.png')
 cats=d['Product.line'].astype(str).unique(); rows=int(np.ceil(len(cats)/2)); fig,axs=plt.subplots(rows,2,figsize=(10,3.5*rows),squeeze=False)
 for ax,c in zip(axs.flat,cats):
  sub=d[d['Product.line'].astype(str)==c]; ax.scatter(sub['Unit.price'],sub['Total'],alpha=.5); ax.set_title(c); ax.set_xlabel('Unit Price'); ax.set_ylabel('Total')
 for ax in axs.flat[len(cats):]: ax.axis('off')
 fig.suptitle('Q6 Facet-style panels by Product Line'); savefig('A5_Q6_facets.png'); d['Group']=d['Gender'].astype(str)+' | '+d['Customer.type'].astype(str); plt.figure(figsize=(9,6))
 for c in d.Group.unique():
  m=d.Group==c; plt.scatter(x[m],y[m],alpha=.5,label=c)
 plt.legend(fontsize=7); plt.title('Q7 Facet-grid style: Gender × Customer Type'); savefig('A5_Q7_facet_grid.png'); chosen=[c for c in ['Unit.price','Quantity','Total','Rating'] if c in num]; scatter_matrix(d[chosen].dropna(),figsize=(8,8),diagonal='hist'); plt.suptitle('Q8 Pairs Plot'); savefig('A5_Q8_pairs.png'); par=d[chosen+['Gender']].copy()
 for c in chosen:
  lo,hi=par[c].min(),par[c].max(); par[c]=(par[c]-lo)/(hi-lo) if hi!=lo else 0
 plt.figure(figsize=(10,6)); parallel_coordinates(par,'Gender',alpha=.2); plt.xticks(rotation=30); plt.title('Q9 Parallel Coordinates'); savefig('A5_Q9_parallel.png'); print('ASSESSMENT 5 COMPLETED')
if __name__=='__main__': run()
